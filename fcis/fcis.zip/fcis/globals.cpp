#include "globals.h"
#include <iostream>
using namespace std;

 string globals::getCurrentDate() {

    auto now =  chrono::system_clock::now();
     time_t currentTime =  chrono::system_clock::to_time_t(now);

    struct tm tm {};
    localtime_s(&tm, &currentTime);
    char buffer[100];
    strftime(buffer, sizeof(buffer), "%Y-%m-%d", &tm);

    return  string(buffer);
}

 string globals::addMonthsToDate(const  string& currentDate, int monthsToAdd) {

    struct tm tm {};

    sscanf_s(currentDate.c_str(), "%d-%d-%d", &tm.tm_year, &tm.tm_mon, &tm.tm_mday);
    tm.tm_year -= 1900;
    tm.tm_mon -= 1;

    tm.tm_mon += monthsToAdd;
    mktime(&tm);

    char buffer[100];
    strftime(buffer, sizeof(buffer), "%Y-%m-%d", &tm);

    return  string(buffer);
}


bool globals::is_staff_exist(int id) {
    return staffs.find(id) != staffs.end();
}

staff globals::get_staff_by_id(int id) {
    if (staffs.find(id) != staffs.end()) {
        return staffs[id];
    }
    cout << "-------------------\nNo User Exist With This ID\n-------------------\n";
    return staff();
}

string globals::get_staff_pass_by_id(int id) {
    return staffs[id].getpassword();
}

string globals::get_staff_name_by_id(int id) {
    return staffs[id].getname();
}

string globals::get_member_pass_by_id(int id) {
    return members[id].getPassword();
}

void globals::add_staff_member(char role) {
    string name, date_of_birth, password;
    cout << "Enter name:\n";
    cin >> name;
    cout << "Enter date of birth:\n";
    cin >> date_of_birth;
    cout << "Enter password:\n";
    cin >> password;
    staff new_staff(staff::getstaffcount() + 1, name, date_of_birth, password, role);
    staffs[new_staff.getid()] = new_staff;
}

void globals::display_staff_member(int id) {
        cout << "-------------------\n";
        cout << "Name: " << staffs[id].getname() << endl;
        cout << "Date Of birth: " << staffs[id].getbirth() << endl;
        cout << "ID: " << staffs[id].getid() << endl;
        cout << "password: " << staffs[id].getpassword() << endl;
        cout << "role: " << staffs[id].getrole() << endl;
        cout << "-------------------\n";
}

void globals::add_member() {
    int c;
    string name, date_of_birth, password;
    bool is_VIP;
    cout << "Enter name:\n";
    cin >> name;
    cout << "Enter date of birth:\n";
    cin >> date_of_birth;
    cout << "Enter password:\n";
    cin >> password;
    cout << "VIP ?\n1 - yes\n2 - no\n";
    cin >> c;
    if (c == 1)
        is_VIP = true;
    else
        is_VIP = false;
    member new_member(member::getMemberCount() + 1, name, date_of_birth, is_VIP, password);
    members[new_member.getId()] = new_member;
}

void globals::display_member_by_id(int id) {
    cout << "-------------------\n";
    cout << "Name: " << members[id].getName() << endl;
    cout << "Date Of birth: " << members[id].getDateOfBirth() << endl;
    cout << "VIP: " << (members[id].getIsVIP() ? "Yes" : "No") << endl;
    cout << "ID: " << members[id].getId() << endl;
    cout << "password: " << members[id].getPassword() << endl;
    cout << "-------------------\n";
}

bool globals::is_member_exist(int id) {
    return members.find(id) != members.end();
}

member globals::get_member_by_id(int id) {
    return members[id];
}

void globals::display_member_classes_by_id(int id) {
    for (auto i : members[id].classes_id) {
        cout << "-------------------\n";
        cout << "Class name: " << i.second.first.first << endl;
        cout << "Class ID: " << i.first << endl;
        cout << "Subscription Date: " << i.second.first.second << endl;
        cout << "Expire Date: " << i.second.second << endl;
        cout << "-------------------\n";
    }
}

void globals::display_member_inbox_by_id(int mem_id) {
    if (members[mem_id].inbox.size() > 0) {
        for (int i = 0; i < members[mem_id].inbox.size(); i++) {
            cout << "-------------------\n";
            cout << members[mem_id].inbox.at(i) << endl;
            cout << "-------------------\n";
        }
    }
    else
        cout << "You Don't Have Messages yet\n";
}

void globals::display_all_members() {
    if (members.size() > 0) {
        for (auto i : members) {
            cout << "-------------------\n";
            cout << "member ID: " << i.first << endl;
            cout << "member Name: " << i.second.getName() << endl;
            cout << "member Date Of Birth: " << i.second.getDateOfBirth() << endl;
            cout << "VIP: " << (i.second.getIsVIP() ? "YES" : "NO") << endl;
            cout << "member Password: " << i.second.getPassword() << endl;
            cout << "-------------------\n";
        }
    }
    else cout << "-------------------\nNo Members Exist Yet\n-------------------\n";
}

bool globals::search_class_by_id(int mem_id, int class_id) {
    if (members.find(mem_id) != members.end()) {
        return members[mem_id].classes_id.find(class_id) != members[mem_id].classes_id.end();
    }
    return false;
}

void globals::add_class() {
    string title, coachName, dateAndTime;
    int coach_id;
    int capacity;
    cout << "Enter Class Name:\n";
    cin >> title;
    cout << "Enter Coach ID:\n";
    cin >> coach_id;
    if (staffs[coach_id].getrole() == 'c') {
    cout << "Enter Date and Time:\n";
    cin >> dateAndTime;
    cout << "Enter Class Capacity:\n";
    cin >> capacity;
    classes new_class(classes::getclasscount() + 1, coach_id ,title, staffs[coach_id].getname() , dateAndTime, capacity);
    classess[new_class.getId()] = new_class;
    }
    else cout << "-------------------\nNo Coach With This ID\n-------------------\n";
}

void globals::display_classes() {
    if (classess.size() > 0) {
        for (auto i : classess) {
            cout << "-------------------\n";
            cout << "Class ID: " << i.first << endl;
            cout << "Class Name: " << i.second.getTitle() << endl;
            cout << "Coach ID: " << i.second.getCoachID() << endl;
            cout << "Coach Name: " << i.second.getCoachName() << endl;
            cout << "Date and Time: " << i.second.getDateAndTime() << endl;
            cout << "Capacity: " << i.second.getCapacity() << endl;
            cout << "Current Size: " << i.second.getSize() << endl;
            cout << "-------------------\n";
        }
    }
    else
        cout << "-------------------\nNo Classes Exist\n-------------------\n";
}

bool globals::is_class_exist(int class_id) {
    for (auto i : classess) {
        if (i.first == class_id) {
            return true;
        }
    }
    return false;
}

void globals::delete_class_by_id(int class_id) {
    classess.erase(class_id);
    classes::decrementClassCount();
}


void globals::join_class(int id) {
    int in;
    bool flag = 1;
    display_classes();
    cout << "choose what kind of class you want to join (enter id) \n";

    cin >> in;
    if (is_class_exist(in)) {
        if (classess[in].listOfMembers.find(id) == classess[in].listOfMembers.end()) {
            if (classess[in].getSize() >= classess[in].getCapacity()) {
                if (members[id].getIsVIP()) {
                    classess[in].wait_list_vip.push(id);
                    cout << "-------------------\nyou are added in vip wait list\n-------------------\n";
                }
                else {
                    classess[in].wait_list.push(id);
                    cout << "-------------------\nyou are added in wait list\n-------------------\n";
                }
            }
            else {
                int subs;
                string date, exp;
                date = getCurrentDate();
                cout << "enter you subscription type\n[1] - monthly\n[2] - 3 months\n[3]- 6 months\n[4] - yearly\n";
                cin >> subs;
                if (subs == 1) {
                    members[id].subscription_type = "1 month";
                    exp = addMonthsToDate(date, 1);
                }
                else if (subs == 2) {
                    members[id].subscription_type = "3 month";
                    exp = addMonthsToDate(date, 3);
                }
                else if (subs == 3) {
                    members[id].subscription_type = "6 month";
                    exp = addMonthsToDate(date, 6);
                }
                else if (subs == 4) {
                    members[id].subscription_type = "12 month";
                    exp = addMonthsToDate(date, 12);
                }
                members[id].classes_id[in].first.first = classess[in].getTitle();
                members[id].classes_id[in].first.second = date;
                members[id].classes_id[in].second = exp;
                classess[in].listOfMembers[id] = classess[in].getTitle();
                classess[in].setSize(classess[in].getSize() + 1);
                cout << "-------------------\nYou have successfully joined the class\n-------------------\n";
            }
        }
        else {
            cout << "-------------------\nyou already joined to this class\n-------------------\n";
        }
    }
    else {
        cout << "-------------------\ninvalid class id\n-------------------\n";
    }
        
}



void globals::renew_subscription(int mem_id, int class_id, int period) {
    members[mem_id].classes_id[class_id].second = addMonthsToDate(members[mem_id].classes_id[class_id].second, period);
}

void globals::cancel_subscription(int mem_id, int class_id) {
    members[mem_id].classes_id.erase(class_id);
}

void globals::cancel_class(int id)
{
    display_member_classes_by_id(id);
    cout << "Enter the class ID to leave:\n";
    int idd;
    cin >> idd;
    if (is_class_exist(idd) && classess[idd].listOfMembers.find(id) != classess[idd].listOfMembers.end()) {
        int count = classess[idd].getSize();
        if (count > 0) {
            classess[idd].setSize(count - 1);
        }
        classess[idd].listOfMembers.erase(id);
        members[id].classes_id.erase(idd);
        cout << "-------------------\nYou have successfully left the class\n-------------------\n";

       
        if (!classess[idd].wait_list_vip.empty()) {
            string date, exp;
            date = getCurrentDate();
            exp = addMonthsToDate(date, 1);
            int next_vip_id = classess[idd].wait_list_vip.front();
            members[next_vip_id].inbox.push_back("You are added to class " + classess[idd].getTitle());
            classess[idd].wait_list_vip.pop();
            members[next_vip_id].classes_id[idd].first.first = classess[idd].getTitle();
            members[next_vip_id].classes_id[idd].first.second = date;
            members[next_vip_id].classes_id[idd].second = exp;            
            classess[idd].listOfMembers[next_vip_id] = classess[idd].getTitle();
            classess[idd].setSize(classess[idd].getSize() + 1);
        }
       
        else if (!classess[idd].wait_list.empty()) {
            string date, exp;
            date = getCurrentDate();
            exp = addMonthsToDate(date, 1);
            int next_id = classess[idd].wait_list.front();
            members[next_id].inbox.push_back("You are added to class " + classess[idd].getTitle());
            classess[idd].wait_list.pop();
            members[next_id].classes_id[idd].first.first = classess[idd].getTitle();
            members[next_id].classes_id[idd].first.second = date;
            members[next_id].classes_id[idd].second = exp;
            classess[idd].listOfMembers[next_id] = classess[idd].getTitle();
            classess[idd].setSize(classess[idd].getSize() + 1);
        }

    }
    else {
        cout << "-------------------\nThis member is not enrolled in the selected class\n-------------------\n";
    }
}

void globals::view_workout(int id)
{
    if (members[id].workout_history.size() == 0) {
        cout << "-------------------\nyou dont have workout history yet!\n-------------------\n";
    }
    else {
        for (int i = 0; i < members[id].workout_history.size(); i++) {
            cout << i + 1 << " -> " << members[id].workout_history[i] << "\n";
        }
    }
}

void globals::add_work(int id, string work)
{
    members[id].workout_history.push_back(work);
}


void globals::display_class_by_id(int id) {
    cout << "-------------------\n";
    cout << "Class ID: " << classess[id].getId() << endl;
    cout << "Class Name: " << classess[id].getTitle() << endl;
    cout << "Coach ID: " << classess[id].getCoachID() << endl;
    cout << "Coach Name: " << classess[id].getCoachName() << endl;
    cout << "Date and Time: " << classess[id].getDateAndTime() << endl;
    cout << "Capacity: " << classess[id].getCapacity() << endl;
    cout << "Current Size: " << classess[id].getSize() << endl;
    cout << "-------------------\n";
}

void globals::display_coach_classes_by_id(int id) {
    bool s = false;
    for (auto i : classess) {
        if (i.second.getCoachID() == id) {
            s = true;
            display_class_by_id(i.first);
        }
    }
    if (!s)
        cout << "-------------------\nYou Don't manage any class yet\n-------------------\n";
    
}

void globals::add_court() {
    int coachID;
    string location;
    string date;
    string time;
    cout << "Enter Court Location\n";
    cin >> location;
    cout << "Enter Court Time\n";
    cin >> time;
    cout << "Enter Court Date\n";
    cin >> date;
    cout << "Enter Coach ID\n";
    cin >> coachID;
    if (staffs[coachID].getrole() == 'c') {
        Padel p(Padel::getPadelCount() + 1, location, staffs[coachID].getname(), coachID, date, time);
        padels[p.getCourtID()] = p;
        cout << "-------------------\nAdded Successfully\n-------------------\n";
    }
    else cout << "-------------------\nInvalid Coach ID\n-------------------\n";
}

void globals::display_coach_courts_by_id(int id) {
    bool s = false;
    for (auto i : padels) {
        if (i.second.getCoachID() == id) {
            s = true;
            display_court_by_id(i.first);
        }
    }
    if (!s)
        cout << "-------------------\nYou Don't manage any courts yet\n-------------------\n";
    
}

void globals::display_court_by_id(int id) {
    cout << "-------------------\n";
    cout << "Court ID: " << padels[id].getCourtID() << "\n";
    cout << "Location: " << padels[id].getLocation() << "\n";
    cout << "Coach Name: " << padels[id].getCoachName() << "\n";
    cout << "Coach ID: " << padels[id].getCoachName() << "\n";
    cout << "Date & Time: " << padels[id].getDate() << " " << padels[id].getTime() << "\n";
    cout << "Status: " << (padels[id].getIsBooked() ? "Booked by " + padels[id].getBookedBy() : "Available") << "\n";
    cout << "-------------------\n";
}

void globals::display_padel_courts() {
    for (auto i : padels) {
        cout << "-------------------\n";
        cout << "Court ID: " << i.second.getCourtID() << "\n";
        cout << "Location: " << i.second.getLocation() << "\n";
        cout << "Coach Name: " << i.second.getCoachName() << "\n";
        cout << "Coach ID: " << i.second.getCoachID() << "\n";
        cout << "Date & Time: " << i.second.getDate() << " " << i.second.getTime() << "\n";
        cout << "Status: " << (i.second.getIsBooked() ? "Booked by " + i.second.getBookedBy() : "Available") << "\n";
        cout << "-------------------\n";
    }
}

bool globals::is_court_exist(int id) {
    return padels.find(id) != padels.end();
}

bool globals::is_court_booked(int id) {
    return (padels[id].getBookedBy() == "" ? true : false);
}

void globals::book_padel_court(int mem_id , int p_id) {
    padels[p_id].setBookedBy(members[mem_id].getName());
}

void globals::display_closest_time_court(string date, string time, string location , int mem_id) {
    bool found = false;
    int id;
    int c;
    for (auto& court : padels) {
        if (court.second.getLocation() == location &&
            court.second.getDate() == date &&
            court.second.getTime() >= time ) {
            cout << "there is closest available court\n";
            cout << "-------------------\n";
            cout << "Court ID: " << court.second.getCourtID() << "\n";
            cout << "Location: " << court.second.getLocation() << "\n";
            cout << "Coach Name: " << court.second.getCoachName() << "\n";
            cout << "Coach ID: " << court.second.getCoachID() << "\n";
            cout << "Date & Time: " << court.second.getDate() << " " << court.second.getTime() << "\n";
            cout << "-------------------\n";
            id = court.first;
            found = true;
            break;
        }
    }
    if (!found) {
        cout << "-------------------\nNo available courts found\n-------------------\n";
    }
    else {
        cout << "Book It ?\n1 - yes\n2 - no\n";
        cin >> c;
        if (c == 1)
            book_padel_court(mem_id, id);
    }
}

void globals::display_court_by_date_time_loc(int mem_id) {
    bool found = false;
    int c, id;
    string date, time, loc;
    cout << "Enter Date:\n";
    cin >> date;
    cout << "Enter Time:\n";
    cin >> time;
    cout << "Enter Location\n";
    cin >> loc;
    for (auto& court : padels) {
        if (court.second.getLocation() == loc &&
            court.second.getDate() == date &&
            court.second.getTime() == time &&
            court.second.getIsBooked() == false) {
            found = true;
            id = court.second.getCourtID();
            cout << "-------------------\n";
            cout << "Court ID: " << court.second.getCourtID() << "\n";
            cout << "Location: " << court.second.getLocation() << "\n";
            cout << "Coach Name: " << court.second.getCoachName() << "\n";
            cout << "Coach ID: " << court.second.getCoachID() << "\n";
            cout << "Date & Time: " << court.second.getDate() << " " << court.second.getTime() << "\n";
            cout << "-------------------\n";
        }
    }
    if (!found) {
        cout << "-------------------\nThere is no available court\n-------------------\n";
    }
    else {
        cout << "Book It ?\n1 - yes\n2 - no\n";
        cin >> c;
        if (c == 1) {
            book_padel_court(mem_id, id);
        }
    }
}

void globals::remove_court_by_id(int id) {
    padels.erase(id);
}
