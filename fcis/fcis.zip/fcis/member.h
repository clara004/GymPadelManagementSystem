#pragma once
#include <string>
#include <map>
#include<vector>
using namespace std;

class member {
private:
    int id;
    string name;
    string date_of_birth;
    bool is_VIP;
    string password;
    static int member_count;

public:
    string subscription_type, subscription_expire;
    map<int /*class id*/, pair<pair<string /*class name*/, string /*sub date*/>, string /*expire date*/>> classes_id;
    vector<string>workout_history;
    vector<string>inbox;
    member();
    member(int id, string name, string date_of_birth, bool is_VIP, string password);

    static int getMemberCount();

    int getId() const;
    string getName() const;
    string getDateOfBirth() const;
    bool getIsVIP() const;
    string getPassword() const;

    void setId(int id);
    void setName(string name);
    void setDateOfBirth(string date_of_birth);
    void setIsVIP(bool is_VIP);
    void setPassword(string password);

};
