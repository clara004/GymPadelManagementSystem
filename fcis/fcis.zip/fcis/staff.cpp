#include "staff.h"
#include <iostream>
using namespace std;

int staff::staff_count = 0;

staff::staff() {
    id = 0;
    name = "";
    role = 'n';
    date_of_birth = "";
    password = "";
}

staff::staff(int id, string name, string date_of_birth, string password, char role) {
    this->id = id;
    this->name = name;
    this->date_of_birth = date_of_birth;
    this->password = password;
    this->role = role;
    staff_count++;
}

int staff::getstaffcount() {
    return staff_count;
}

int staff::getid() {
    return id;
}

void staff::setid(int id) {
    this->id = id;
}

void staff::setname(string name) {
    this->name = name;
}

void staff::setrole(char role) {
    this->role = role;
}

void staff::setpassword(string pass) {
    this->password = pass;
}

void staff::setbirth(string birth) {
    date_of_birth = birth;
}

string staff::getname() {
    return name;
}

char staff::getrole() {
    return role;
}

string staff::getpassword() {
    return password;
}

string staff::getbirth() {
    return date_of_birth;
}

staff staff::get_info() {
    staff s;
    s.setid(getid());
    s.setname(getname());
    s.setrole(getrole());
    s.setpassword(getpassword());
    s.setbirth(getbirth());
    return s;
}
