#pragma once
#include <string>
using namespace std;

class staff {
private:
    int id;
    string name;
    string date_of_birth;
    string password;
    char role;
    static int staff_count;

public:
    staff();
    staff(int id, string name, string date_of_birth, string password, char role);

    static int getstaffcount();

    int getid();
    string getname();
    char getrole();
    string getpassword();
    string getbirth();

    void setid(int id);
    void setname(string name);
    void setrole(char role);
    void setpassword(string pass);
    void setbirth(string birth);

    staff get_info();
};
